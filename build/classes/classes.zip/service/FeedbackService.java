package service;

import classes.Feedback;
import daos.DaoFeedback;
import enuns.StatusFeedback;

public class FeedbackService {

    private DaoFeedback daoFeedback = new DaoFeedback();

    public void registrarFeedback(Feedback feedback) {
        feedback.setStatus(StatusFeedback.Enviado);
        daoFeedback.Inserir(feedback);
    }
}
