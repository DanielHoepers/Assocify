package service;

import classes.Financeiro;
import classes.PagamentoMensalidade;
import daos.DaoFinanceiro;
import daos.DaoPagamentoMensalidade;
import enuns.StatusPagamento;
import enuns.TipoFinanceiro;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FinanceiroService {

    private DaoFinanceiro daoFinanceiro = new DaoFinanceiro();
    private DaoPagamentoMensalidade daoPagamento = new DaoPagamentoMensalidade();

    public BigDecimal calcularJuros(PagamentoMensalidade pagamento) {
        long mesesAtraso = LocalDate.now().getMonthValue() - pagamento.getData().getMonthValue();
        BigDecimal juros = new BigDecimal("0.05"); // 5% de juros
        BigDecimal total = pagamento.getValor().add(pagamento.getValor().multiply(juros));
        return total.setScale(2);
    }

    public void registrarPagamento(PagamentoMensalidade pagamento) {
        pagamento.setStatus(StatusPagamento.Pago);
        pagamento.setData(LocalDate.now());
        daoPagamento.Editar(pagamento);
        daoFinanceiro.Inserir(new Financeiro(pagamento.getValor(), TipoFinanceiro.Entrada, "Mensalidade paga"));
    }

    public void gerarRecibo(PagamentoMensalidade pagamento) {
        System.out.println("Recibo gerado para pagamento no valor de R$" + pagamento.getValor());
    }
}
