package services;

import classes.Associado;
import classes.PagamentoMensalidade;
import daos.DaoAssociado;
import daos.DaoPagamentoMensalidade;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import service.NotificacaoService;

public class AssociadoService {

    private DaoAssociado daoAssociado = new DaoAssociado();
    private DaoPagamentoMensalidade daoPagamento = new DaoPagamentoMensalidade();

    public void verificarInadimplencia(Associado associado) {
        List<PagamentoMensalidade> pagamentos = daoPagamento.buscarPorAssociado(associado);
        for (PagamentoMensalidade mensalidade : pagamentos) {
            if (mensalidade.getData().isBefore(LocalDate.now().minusMonths(1)) &&
                mensalidade.getStatus().toString().equals("PENDENTE")) {
                associado.setContaDesativada(true);
                daoAssociado.Editar(associado);
                break;
            }
        }
    }

    public BigDecimal calcularSaldoAssociado(Associado associado) {
        List<PagamentoMensalidade> pagamentos = daoPagamento.buscarPorAssociado(associado);
        return pagamentos.stream()
                .filter(p -> p.getStatus().toString().equals("PENDENTE"))
                .map(PagamentoMensalidade::getValor)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void cadastrarAssociado(Associado associado) {
        daoAssociado.Inserir(associado);
        new NotificacaoService().enviarBoasVindas(associado);
    }

    public void atualizarAssociado(Associado associado) {
        daoAssociado.Editar(associado);
    }

    public void excluirAssociado(Associado associado) {
        daoAssociado.Remover(associado);
    }
}
