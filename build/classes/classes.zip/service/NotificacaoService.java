package service;

import classes.Associado;
import classes.Notificacao;
import daos.DaoNotificacao;

public class NotificacaoService {

    private DaoNotificacao daoNotificacao = new DaoNotificacao();

    public void enviarBoasVindas(Associado associado) {
        String mensagem = "Bem-vindo(a), " + associado.getNomeCompleto() + "! Sua associação foi concluída com sucesso.";
        Notificacao notificacao = new Notificacao(associado, mensagem, false, true);
        daoNotificacao.Inserir(notificacao);
    }
}
