package service;

import daos.DaoUsuario;
import classes.Usuario;

public class AutenticacaoService {

    private DaoUsuario daoUsuario = new DaoUsuario();

    public boolean autenticar(String login, String senha) {
        Usuario usuario = daoUsuario.buscarPorLogin(login);
        return usuario != null && usuario.getSenha().equals(senha);
    }
}
