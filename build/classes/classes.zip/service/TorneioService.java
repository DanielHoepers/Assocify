package service;

import classes.Associado;

public class TorneioService {

    public void validarInscricao(Associado associado) {
        if (associado.isInadimplente()) {
            throw new RuntimeException("Associado inadimplente não pode se inscrever.");
        }
    }
}
