/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import enuns.StatusPagamento;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author danie
 */
public class PagamentoMensalidade {
    private int id;
    private int associadoId;
    private LocalDate dataPagamento;
    private BigDecimal valor;
    private BigDecimal juros;
    private Enum<StatusPagamento> status;

    public PagamentoMensalidade(int associadoId, BigDecimal valor, BigDecimal juros, Enum<StatusPagamento> status) {
        this.associadoId = associadoId;
        this.dataPagamento = LocalDate.now();
        this.valor = valor;
        this.juros = juros;
        this.status = status;
    }

    public int getAssociadoId() {
        return associadoId;
    }

    public void setAssociadoId(int associadoId) {
        this.associadoId = associadoId;
    }

    public LocalDate getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(LocalDate dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public BigDecimal getJuros() {
        return juros;
    }

    public void setJuros(BigDecimal juros) {
        this.juros = juros;
    }

    public Enum<StatusPagamento> getStatus() {
        return status;
    }

    public void setStatus(Enum<StatusPagamento> status) {
        this.status = status;
    }
}
