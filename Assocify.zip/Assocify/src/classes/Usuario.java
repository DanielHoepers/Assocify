package classes;

import enuns.TipoUsuario;

public class Usuario {
    private int id;
    private String login;
    private String senha;
    private Enum<TipoUsuario> perfil;
    private boolean ativo;

    public Usuario(String login, String senha, Enum<TipoUsuario> perfil, boolean ativo) {
        this.login = login;
        this.senha = senha;
        this.perfil = perfil;
        this.ativo = ativo;
    }

    public String getLogin() {
        return login;
    }

    public String getSenha() {
        return senha;
    }

    public Enum<TipoUsuario> getPerfil() {
        return perfil;
    }

    public boolean isAtivo() {
        return ativo;
    }
}
