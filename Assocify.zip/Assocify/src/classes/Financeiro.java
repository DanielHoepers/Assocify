/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import enuns.TipoTorneio;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author danie
 */
public class Financeiro {
    private int id;
    private LocalDate data;
    private BigDecimal valor;
    private Enum<TipoTorneio> tipo;
    private String descricao;

    public Financeiro(BigDecimal valor, Enum<TipoTorneio> tipo, String descricao) {
        this.valor = valor;
        this.tipo = tipo;
        this.descricao = descricao;
        this.data = LocalDate.now();
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Enum<TipoTorneio> getTipo() {
        return tipo;
    }

    public void setTipo(Enum<TipoTorneio> tipo) {
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
