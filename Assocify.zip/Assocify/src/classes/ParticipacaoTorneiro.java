package classes;

import java.util.ArrayList;

public class ParticipacaoTorneiro {
    private int id;
    private int torneioId;
    private int associadoId;
    private ArrayList<Passaro> passaros;
    private boolean certificadoEmitido;
    private int colocacao;

    public ParticipacaoTorneiro(int torneioId, int associadoId, ArrayList<Passaro> passaros, boolean certificadoEmitido, int colocacao) {
        this.torneioId = torneioId;
        this.associadoId = associadoId;
        this.passaros = passaros;
        this.certificadoEmitido = certificadoEmitido;
        this.colocacao = colocacao;
    }

    public int getTorneioId() {
        return torneioId;
    }

    public void setTorneioId(int torneioId) {
        this.torneioId = torneioId;
    }

    public int getAssociadoId() {
        return associadoId;
    }

    public void setAssociadoId(int associadoId) {
        this.associadoId = associadoId;
    }

    public ArrayList<Passaro> getPassaros() {
        return passaros;
    }

    public void setPassaros(ArrayList<Passaro> passaros) {
        this.passaros = passaros;
    }

    public boolean isCertificadoEmitido() {
        return certificadoEmitido;
    }

    public void setCertificadoEmitido(boolean certificadoEmitido) {
        this.certificadoEmitido = certificadoEmitido;
    }

    public int getColocacao() {
        return colocacao;
    }

    public void setColocacao(int colocacao) {
        this.colocacao = colocacao;
    }
}
