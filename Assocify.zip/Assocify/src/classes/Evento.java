/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.time.LocalDate;
import java.time.LocalTime;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author danie
 */
@Entity
@Table(name = "Evento")
public class Evento {
    private int id;
    private String nome;
    private String descricao;
    private LocalDate data;
    private LocalTime hora;
    private String local;
    private int limiteParticipantes;
    private boolean encerrado;

    public Evento(String nome, String descricao, String local, int limiteParticipantes) {
        this.nome = nome;
        this.descricao = descricao;
        this.local = local;
        this.limiteParticipantes = limiteParticipantes;
        this.encerrado = false;
        this.data = LocalDate.now();
        this.hora = LocalTime.now();

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public int getLimiteParticipantes() {
        return limiteParticipantes;
    }

    public void setLimiteParticipantes(int limiteParticipantes) {
        this.limiteParticipantes = limiteParticipantes;
    }

    public boolean isEncerrado() {
        return encerrado;
    }

    public void setEncerrado(boolean encerrado) {
        this.encerrado = encerrado;
    }
}
