/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author danie
 */
public class Notificacao {
    private int id;
    private int associadoId;
    private String mensagem;
    private LocalDate dataEnvio;
    private boolean lida;
    private boolean importante;

    public Notificacao(int associadoId, String mensagem, boolean lida, boolean importante) {
        this.associadoId = associadoId;
        this.mensagem = mensagem;
        this.dataEnvio = LocalDate.now();
        this.lida = lida;
        this.importante = importante;
    }

    public int getAssociadoId() {
        return associadoId;
    }

    public void setAssociadoId(int associadoId) {
        this.associadoId = associadoId;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public LocalDate getDataEnvio() {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDate dataEnvio) {
        this.dataEnvio = dataEnvio;
    }

    public boolean isLida() {
        return lida;
    }

    public void setLida(boolean lida) {
        this.lida = lida;
    }

    public boolean isImportante() {
        return importante;
    }

    public void setImportante(boolean importante) {
        this.importante = importante;
    }
}
