/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.time.LocalDate;

/**
 *
 * @author danie
 */
public class Carteirinha {
    private int id;
    private int associadoId;
    private String codigoSocio;
    private String filiacao;
    private LocalDate dataEmissao;
    private LocalDate validade;
    private String nomeAssociacao;
    private String cnpjAssociacao;

    public Carteirinha(int associadoId, String codigoSocio, String filiacao, LocalDate validade, String nomeAssociacao, String cnpjAssociacao) {
        this.associadoId = associadoId;
        this.codigoSocio = codigoSocio;
        this.filiacao = filiacao;
        this.dataEmissao = LocalDate.now();
        this.validade = validade;
        this.nomeAssociacao = nomeAssociacao;
        this.cnpjAssociacao = cnpjAssociacao;
    }

    public int getAssociadoId() {
        return associadoId;
    }

    public void setAssociadoId(int associadoId) {
        this.associadoId = associadoId;
    }

    public String getCodigoSocio() {
        return codigoSocio;
    }

    public void setCodigoSocio(String codigoSocio) {
        this.codigoSocio = codigoSocio;
    }

    public String getFiliacao() {
        return filiacao;
    }

    public void setFiliacao(String filiacao) {
        this.filiacao = filiacao;
    }

    public LocalDate getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(LocalDate dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public LocalDate getValidade() {
        return validade;
    }

    public void setValidade(LocalDate validade) {
        this.validade = validade;
    }

    public String getNomeAssociacao() {
        return nomeAssociacao;
    }

    public void setNomeAssociacao(String nomeAssociacao) {
        this.nomeAssociacao = nomeAssociacao;
    }

    public String getCnpjAssociacao() {
        return cnpjAssociacao;
    }

    public void setCnpjAssociacao(String cnpjAssociacao) {
        this.cnpjAssociacao = cnpjAssociacao;
    }
}
