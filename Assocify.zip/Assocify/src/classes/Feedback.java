package classes;

import java.time.LocalDate;

public class Feedback {
    private int id;
    private int associadoId;
    private int eventoId;
    private int TorneioId;
    private String comentario;
    private LocalDate data;

    public Feedback(int associadoId, int eventoId, int torneioId, String comentario) {
        this.associadoId = associadoId;
        this.eventoId = eventoId;
        this.TorneioId = torneioId;
        this.comentario = comentario;
        this.data = LocalDate.now();
    }

    public int getAssociadoId() {
        return associadoId;
    }

    public void setAssociadoId(int associadoId) {
        this.associadoId = associadoId;
    }

    public int getEventoId() {
        return eventoId;
    }

    public void setEventoId(int eventoId) {
        this.eventoId = eventoId;
    }

    public int getTorneioId() {
        return TorneioId;
    }

    public void setTorneioId(int torneioId) {
        TorneioId = torneioId;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }
}
