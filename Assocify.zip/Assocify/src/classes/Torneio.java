/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import enuns.TipoTorneio;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author danie
 */
public class Torneio {
    private int id;
    private String nome;
    private LocalDate data;
    private String local;
    private Enum<TipoTorneio> tipo;
    private boolean finalizado;

    public Torneio(String nome, LocalDate data, String local, Enum<TipoTorneio> tipo, boolean finalizado) {
        this.nome = nome;
        this.data = data;
        this.local = local;
        this.tipo = tipo;
        this.finalizado = finalizado;
    }
}
