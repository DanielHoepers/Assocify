/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.main;

import classes.Associado;

/**
 *
 * @author danie
 */
public class main {
    public static void main(String[] args) {
        Associado x = new Associado("Daniel", "123", "TESTE@EMAIL", "ervoe", "sdjhvb",
    }
 
}
