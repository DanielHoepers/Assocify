package enuns;

public enum TipoTorneio {
    Canto,
    Beleza
}
