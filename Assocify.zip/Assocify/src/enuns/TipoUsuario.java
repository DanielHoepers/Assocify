package enuns;

public enum TipoUsuario {
    Associado,
    Administrador
}
